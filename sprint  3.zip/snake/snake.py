import random
import sys

import pygame

# Инициализация Pygame
pygame.init()

# Константы
SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480
GRID_SIZE = 20
GRID_WIDTH = SCREEN_WIDTH // GRID_SIZE
GRID_HEIGHT = SCREEN_HEIGHT // GRID_SIZE
FPS = 10

# Цвета
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
WHITE = (255, 255, 255)

# Направления
UP = (0, -1)
DOWN = (0, 1)
LEFT = (-1, 0)
RIGHT = (1, 0)



class Snake:
    """Класс, описывающий змею."""

    def __init__(self):
        self.reset()

    def reset(self):
        """Сброс состояния змеи."""
        self.length = 3
        self.positions = [(GRID_WIDTH // 2, GRID_HEIGHT // 2)]
        self.direction = random.choice([UP, DOWN, LEFT, RIGHT])
        self.score = 0

    def get_head_position(self):
        """Получить позицию головы змеи."""
        return self.positions[0]

    def turn(self, point):
        """Повернуть змею в указанном направлении."""
        if self.length > 1 and (point[0] * -1, point[1] * -1) == self.direction:
            return
        else:
            self.direction = point

    def move(self):
        """Переместить змею на один шаг."""
        head = self.get_head_position()
        x, y = self.direction
        new_x = (head[0] + x) % GRID_WIDTH
        new_y = (head[1] + y) % GRID_HEIGHT
        new_position = (new_x, new_y)

        # Проверка на столкновение с собой
        if new_position in self.positions[1:]:
            self.reset()
            return False

        # Проверка на столкновение со стеной
        if (new_x < 0 or new_x >= GRID_WIDTH or
                new_y < 0 or new_y >= GRID_HEIGHT):
            self.reset()
            return False

        self.positions.insert(0, new_position)
        if len(self.positions) > self.length:
            self.positions.pop()
        return True

    def draw(self, surface):
        """Отрисовать змею на поверхности."""
        for p in self.positions:
            rect = pygame.Rect(
                (p[0] * GRID_SIZE, p[1] * GRID_SIZE),
                (GRID_SIZE, GRID_SIZE)
            )
            pygame.draw.rect(surface, GREEN, rect)
            pygame.draw.rect(surface, BLACK, rect, 1)

    def grow(self):
        """Увеличить длину змеи."""
        self.length += 1
        self.score += 1



class Apple:
    """Класс, описывающий яблоко."""

    def __init__(self):
        self.position = (0, 0)
        self.randomize_position()

    def randomize_position(self):
        """Случайно разместить яблоко на игровом поле."""
        self.position = (
            random.randint(0, GRID_WIDTH - 1),
            random.randint(0, GRID_HEIGHT - 1)
        )

    def draw(self, surface):
        """Отрисовать яблоко на поверхности."""
        rect = pygame.Rect(
            (self.position[0] * GRID_SIZE, self.position[1] * GRID_SIZE),
            (GRID_SIZE, GRID_SIZE)
        )
        pygame.draw.rect(surface, RED, rect)
        pygame.draw.rect(surface, BLACK, rect, 1)



def draw_grid(surface):
    """Отрисовать сетку на поверхности."""
    for y in range(0, SCREEN_HEIGHT, GRID_SIZE):
        for x in range(0, SCREEN_WIDTH, GRID_SIZE):
            rect = pygame.Rect((x, y), (GRID_SIZE, GRID_SIZE))
            pygame.draw.rect(surface, BLACK, rect, 1)



def main():
    """Основная функция игры."""
    clock = pygame.time.Clock()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption('Sprint3')

    surface = pygame.Surface(screen.get_size())
    surface = surface.convert()

    snake = Snake()
    apple = Apple()

    font = pygame.font.SysFont('arial', 20)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_q:
                    pygame.quit()
                    sys.exit()
                elif event.key == pygame.K_r:
                    snake.reset()
                    apple.randomize_position()
                elif event.key == pygame.K_UP:
                    snake.turn(UP)
                elif event.key == pygame.K_DOWN:
                    snake.turn(DOWN)
                elif event.key == pygame.K_LEFT:
                    snake.turn(LEFT)
                elif event.key == pygame.K_RIGHT:
                    snake.turn(RIGHT)

        if not snake.move():
            # Отображение Game Over
            game_over_text = font.render('Game Over! Press R to restart or Q to quit', True, WHITE)
            screen.blit(game_over_text, (SCREEN_WIDTH // 2 - game_over_text.get_width() // 2,
                                           SCREEN_HEIGHT // 2 - game_over_text.get_height() // 2))
            pygame.display.update()
            waiting = True
            while waiting:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                    elif event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_q:
                            pygame.quit()
                            sys.exit()
                        elif event.key == pygame.K_r:
                            snake.reset()
                            apple.randomize_position()
                            waiting = False

        if snake.get_head_position() == apple.position:
            snake.grow()
            apple.randomize_position()
            # Убедиться, что яблоко не появляется внутри змеи
            while apple.position in snake.positions:
                apple.randomize_position()

        surface.fill(BLACK)
        draw_grid(surface)
        snake.draw(surface)
        apple.draw(surface)

        screen.blit(surface, (0, 0))

        # Отображение счёта
        score_text = font.render(f'Score: {snake.score}', True, WHITE)
        screen.blit(score_text, (5, 5))

        pygame.display.update()
        clock.tick(FPS)



if __name__ == '__main__':
    main()
