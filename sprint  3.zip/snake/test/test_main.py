import pygame
import sys
from the_snake import main

def test_main_function_exists():
    assert 'main' in globals()