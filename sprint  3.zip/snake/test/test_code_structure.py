import pytest
import sys
import os

sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from the_snake import Snake, Apple


def test_snake_class_exists():
    assert hasattr(Snake, 'move')
    assert hasattr(Snake, 'turn')
    assert hasattr(Snake, 'grow')

def test_apple_class_exists():
    assert Apple is not None